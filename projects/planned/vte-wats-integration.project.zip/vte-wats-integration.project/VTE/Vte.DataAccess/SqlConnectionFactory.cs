using Microsoft.Data.SqlClient;

namespace Vte.DataAccess;

public interface ISqlConnectionFactory
{
    SqlConnection Create();
}

public sealed class SqlConnectionFactory : ISqlConnectionFactory
{
    private readonly VteDbOptions _options;

    public SqlConnectionFactory(VteDbOptions options)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
        if (string.IsNullOrWhiteSpace(_options.ConnectionString))
            throw new ArgumentException("ConnectionString must be provided.", nameof(options));
    }

    public SqlConnection Create() => new(_options.ConnectionString);
}
