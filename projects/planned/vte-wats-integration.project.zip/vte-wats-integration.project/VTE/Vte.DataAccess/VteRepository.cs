using System.Collections.Generic;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Vte.DataAccess.Models;

namespace Vte.DataAccess;

public interface IVteRepository
{
    IAsyncEnumerable<VteTestRun> StreamTestRunsSinceAsync(DateTime sinceUtc, CancellationToken ct = default);
    Task<VteTestRun?> GetTestRunAsync(Guid indexGuid, CancellationToken ct = default);
}

public sealed class VteRepository : IVteRepository
{
    private readonly ISqlConnectionFactory _factory;
    private readonly ILogger<VteRepository> _log;
    private readonly string _schema;

    public VteRepository(ISqlConnectionFactory factory, ILogger<VteRepository> log, VteDbOptions options)
    {
        _factory = factory ?? throw new ArgumentNullException(nameof(factory));
        _log = log ?? throw new ArgumentNullException(nameof(log));
        _schema = (options?.Schema ?? "dbo").Trim();
    }

    public async IAsyncEnumerable<VteTestRun> StreamTestRunsSinceAsync(
        DateTime sinceUtc,
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct = default)
    {
        // Adjust this query to match the real column names in your deployment.
        var sql = $@"
SELECT *
FROM [{_schema}].[IndexData]
WHERE [Timestamp] >= @SinceUtc
ORDER BY [Timestamp], [Index_GUID];";

        await using var conn = _factory.Create();
        await conn.OpenAsync(ct);

        var headers = await conn.QueryAsync<IndexData>(new CommandDefinition(sql, new { SinceUtc = sinceUtc }, cancellationToken: ct));

        foreach (var header in headers)
        {
            ct.ThrowIfCancellationRequested();
            var steps = await ReadAllStepsAsync(conn, header.Index_GUID, ct);
            yield return new VteTestRun { Header = header, Steps = steps };
        }
    }

    public async Task<VteTestRun?> GetTestRunAsync(Guid indexGuid, CancellationToken ct = default)
    {
        var sql = $@"SELECT * FROM [{_schema}].[IndexData] WHERE [Index_GUID] = @IndexGuid;";

        await using var conn = _factory.Create();
        await conn.OpenAsync(ct);

        var header = await conn.QuerySingleOrDefaultAsync<IndexData>(
            new CommandDefinition(sql, new { IndexGuid = indexGuid }, cancellationToken: ct));

        if (header is null) return null;

        var steps = await ReadAllStepsAsync(conn, indexGuid, ct);
        return new VteTestRun { Header = header, Steps = steps };
    }

    private async Task<IReadOnlyList<VteStepResult>> ReadAllStepsAsync(SqlConnection conn, Guid indexGuid, CancellationToken ct)
    {
        // Normalize the three result tables. Adjust field names to match your schema.

        var sqlNumeric = $@"
SELECT
    [Index_GUID]             AS Index_GUID,
    [TestStepNumber]         AS TestStepNumber,
    [TestName]               AS TestName,
    [TestDescription]        AS TestDescription,
    [TestNumber]             AS TestNumber,
    [TestUnits]              AS TestUnits,
    CAST(0 AS int)           AS Kind,
    CAST([TestResult] AS float) AS NumericResult,
    CAST(NULL AS nvarchar(4000)) AS TextResult,
    CAST([LowLimit] AS float) AS LowLimit,
    CAST([HighLimit] AS float) AS HighLimit,
    CAST([TestResultType] AS int) AS ResultCode
FROM [{_schema}].[TestDataNumeric]
WHERE [Index_GUID] = @IndexGuid;";

        var sqlText = $@"
SELECT
    [Index_GUID]             AS Index_GUID,
    [TestStepNumber]         AS TestStepNumber,
    [TestName]               AS TestName,
    [TestDescription]        AS TestDescription,
    [TestNumber]             AS TestNumber,
    [TestUnits]              AS TestUnits,
    CAST(1 AS int)           AS Kind,
    CAST(NULL AS float)      AS NumericResult,
    CAST([TestResult] AS nvarchar(4000)) AS TextResult,
    CAST(NULL AS float)      AS LowLimit,
    CAST(NULL AS float)      AS HighLimit,
    CAST([TestResultType] AS int) AS ResultCode
FROM [{_schema}].[TestDataText]
WHERE [Index_GUID] = @IndexGuid;";

        var sqlOther = $@"
SELECT
    [Index_GUID]             AS Index_GUID,
    [TestStepNumber]         AS TestStepNumber,
    [TestName]               AS TestName,
    [TestDescription]        AS TestDescription,
    [TestNumber]             AS TestNumber,
    [TestUnits]              AS TestUnits,
    CAST(2 AS int)           AS Kind,
    CAST(NULL AS float)      AS NumericResult,
    CAST([TestResult] AS nvarchar(4000)) AS TextResult,
    CAST(NULL AS float)      AS LowLimit,
    CAST(NULL AS float)      AS HighLimit,
    CAST([TestResultType] AS int) AS ResultCode
FROM [{_schema}].[TestDataOther]
WHERE [Index_GUID] = @IndexGuid;";

        var numeric = await conn.QueryAsync<VteStepResult>(new CommandDefinition(sqlNumeric, new { IndexGuid = indexGuid }, cancellationToken: ct));
        var text = await conn.QueryAsync<VteStepResult>(new CommandDefinition(sqlText, new { IndexGuid = indexGuid }, cancellationToken: ct));
        var other = await conn.QueryAsync<VteStepResult>(new CommandDefinition(sqlOther, new { IndexGuid = indexGuid }, cancellationToken: ct));

        return numeric.Concat(text).Concat(other)
            .OrderBy(x => x.TestStepNumber)
            .ToList();
    }
}
