namespace Vte.DataAccess;

public sealed class VteDbOptions
{
    public string ConnectionString { get; init; } = string.Empty;

    /// <summary>Schema name if VTE objects are under a non-dbo schema.</summary>
    public string Schema { get; init; } = "dbo";
}
