namespace Vte.DataAccess.Models;

public sealed record VteTestRun
{
    public IndexData Header { get; init; } = new();
    public IReadOnlyList<VteStepResult> Steps { get; init; } = Array.Empty<VteStepResult>();
}
