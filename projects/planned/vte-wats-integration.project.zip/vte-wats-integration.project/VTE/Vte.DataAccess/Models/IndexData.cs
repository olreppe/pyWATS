namespace Vte.DataAccess.Models;

/// <summary>
/// Execution header (one test run). Validate against your live schema.
/// </summary>
public sealed record IndexData
{
    public Guid Index_GUID { get; init; }

    public Guid Uut_GUID { get; init; }
    public Guid Product_GUID { get; init; }
    public Guid Testplan_GUID { get; init; }
    public Guid TestplanRevision_GUID { get; init; }
    public Guid Testsystem_GUID { get; init; }
    public Guid User_GUID { get; init; }

    public DateTime Timestamp { get; init; }
    public int ExitCode { get; init; }
    public int Result { get; init; }
    public float? TestTime { get; init; }

    public string? Hostname { get; init; }
    public string? Site { get; init; }
    public string? UserName { get; init; }
    public string? ProductName { get; init; }
    public string? TestplanName { get; init; }
    public string? TestplanVariant { get; init; }
    public string? TestplanRevision { get; init; }

    public string? Info1 { get; init; }
    public string? Info2 { get; init; }
    public string? Info3 { get; init; }
}
