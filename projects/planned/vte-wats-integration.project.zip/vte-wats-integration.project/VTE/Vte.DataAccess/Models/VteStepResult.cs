namespace Vte.DataAccess.Models;

public enum VteStepValueKind
{
    Numeric = 0,
    Text = 1,
    Other = 2
}

public sealed record VteStepResult
{
    public Guid Index_GUID { get; init; }
    public int TestStepNumber { get; init; }

    public string? TestName { get; init; }
    public string? TestDescription { get; init; }
    public string? TestNumber { get; init; }
    public string? TestUnits { get; init; }

    public VteStepValueKind Kind { get; init; }

    public double? NumericResult { get; init; }
    public string? TextResult { get; init; }

    public double? LowLimit { get; init; }
    public double? HighLimit { get; init; }

    public int? ResultCode { get; init; }
}
