# VTE → WATS Adapter Skeleton

- `VTE_VEE_WATS_integration.md`: integration guide
- `Vte.DataAccess/`: .NET library skeleton (Dapper + SqlClient)
